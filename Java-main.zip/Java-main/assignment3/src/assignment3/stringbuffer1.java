package assignment3;

public class stringbuffer1 {

	public static void main(String[] args) {
		
		String s1="is a peer class of String ";
		String s2="that provides much of ";
		String s3="the functionality of Strings ";
		StringBuffer sb = new StringBuffer("StringBuffer ");
		sb.append(s1);
		sb.append(s2);
		sb.append(s3);
		System.out.println(sb);

	}

}
