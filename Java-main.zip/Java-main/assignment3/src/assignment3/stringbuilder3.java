package assignment3;

public class stringbuilder3 {

	public static void main(String[] args) {
		
		StringBuilder sb = new StringBuilder("This method returns reversed obj on which it was called ");
		System.out.println(sb);
		sb.reverse();
		System.out.println(sb);

	}

}
