package assignment3;

import java.util.*;

public class stringclass2 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");
		String s=sc.nextLine();
		System.out.println("Enter another String");
		String s1=sc.nextLine();
		System.out.println("Concatenated String  is "+s+s1);

	}

}
