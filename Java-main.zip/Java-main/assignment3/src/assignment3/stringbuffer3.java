package assignment3;

public class stringbuffer3 {

	public static void main(String[] args) {
		
		StringBuffer sb = new StringBuffer("This method returns reversed obj on which it was called ");
		System.out.println(sb);
		sb.reverse();
		System.out.println(sb);

	}

}
